/*
* Date : 3 avril 2019
* Auteur : Pierre-Olivier C�t�
*
#include "MainGui.h"


MainGui::MainGui( Commande* commande, Filtre* filtre, Menu* menu, QWidget* parent)
    : QMainWindow(parent), ui(new Ui::MainWindow),
      commande_(commande), filtre_(filtre), menu_(menu)
{
    // setUI();
    // connectSignalsToSlots();
}
*/
